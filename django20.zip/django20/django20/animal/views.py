from rest_framework import viewsets
from .models import animal
from .serializers import AnimalSerializer

class AnimalViewSet(viewsets.ModelViewSet):
    queryset = animal.objects.all()
    serializer_class = AnimalSerializer