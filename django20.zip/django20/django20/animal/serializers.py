
from rest_framework import serializers
from .models import animal

class AnimalSerializer(serializers.ModelSerializer):
    class Meta:
        model = animal
        fields = '__all__'