from django.urls import path
from . import views

urlpatterns = [
    path('', views.book_info, name='book_info')
]