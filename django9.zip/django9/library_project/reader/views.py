from django.shortcuts import render
from book.models import Book

def book_info(request):
    if request.method == 'POST':
        book = Book.objects.get(pk=request.POST['book_id'])
        context = {'book': book}
        return render(request, 'book_info.html', context)
    else:
        return render(request, 'reader_form.html')