from django.urls import path
from .models import User

urlpatterns = [
    path('', User.get)
]
