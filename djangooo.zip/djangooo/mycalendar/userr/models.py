from django.db import models
from datetime import date

class User(models.Model):
    name = models.CharField(max_length=100)
    surname = models.CharField(max_length=100)
    birthdate = models.DateField()
    url = models.URLField()

    def get(self):
        today = date.today()
        age = today.year - self.birthdate.year - ((today.month, today.day) < (self.birthdate.month, self.birthdate.day))
        return {
            "name": self.name,
            "surname": self.surname,
            "age": age
        }