from django.db import models
from datetime import date


class mycalendarr(models.Model):
    url = models.URLField()

    def get(self):
        today = date.today()
        return {"year": today.year, "month": today.month, "day": today.day}
