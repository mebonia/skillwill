from django.urls import path
from .models import Calendar

urlpatterns = [
    path('', Calendar.get)
]