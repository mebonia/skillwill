from django.shortcuts import render, redirect, get_object_or_404
from .forms import UserForm
from .models import User
from django.urls import reverse

def user_list(request):
    users = User.objects.all()
    return render(request, 'users/user_list.html', {'users': users})

def user_form(request, id=0):
    if request.method == "GET":
        if id == 0:
            form = UserForm()
        else:
            user = get_object_or_404(User, pk=id)
            form = UserForm(instance=user)
        return render(request, 'users/user_form.html', {'form': form})
    else:
        if id == 0:
            form = UserForm(request.POST)
        else:
            user = get_object_or_404(User, pk=id)
            form = UserForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
        return redirect(reverse('user_list'))

def user_delete(request, id):
    user = get_object_or_404(User, pk=id)
    user.delete()
    return redirect(reverse('user_list'))
